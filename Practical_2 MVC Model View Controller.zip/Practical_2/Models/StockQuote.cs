﻿using System;
namespace MyMVC.Models
{
    public class StockQuote
    {
        public string Symbol
        {
            get;
            set;
        }
        public int Price
        {
            get;
            set;
        }
    }
}